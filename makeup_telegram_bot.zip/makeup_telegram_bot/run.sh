echo "Запуск Makeup Telegram Bot"
pip3 install -r requirements.txt
python3 load_data.py
python3 bot.py

